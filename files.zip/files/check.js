const firebase = require('firebase');
const main = require('./../bot.js');
const bot = main.bot;
const Discord = require('discord.js');
const DB = main.database;

const check = function(id, name, avatar, member, _new) {
    avatar = avatar || '';
    let profile = [];
    DB.profile(id).getData('', function(data) {
        profile = data.val();
    });

    setTimeout(function() {
        if(profile==undefined) {
            let randomCode = Math.round(Math.random() * 10000000) + "_" + id;
            let defaut = {
                site: {
                    access: randomCode,
                },

                account: {
                    name: name,
                    picture: avatar,
                    year: Date.now(),
                    yid: id,
                    active: 1,
                    banned: 0
                },
                
                game: {
                    galleons: 68,
                    inventory: '',
                    home: 'none',
                    quest: 0,
                    hp: 100,
                    xp: 0,
                    level: 1,
                    spells: ""
                }
            };
            
            try {              
                DB.source('profiles').addData('', id, defaut);

                if(_new) member = member.user;
                member.createDM().then(channel => {
                    let embed = new Discord.RichEmbed()
                        .setTitle('Welcome to The Marauders') 
                        .setColor(0xF9B234)
                        .addField(' • begins in the Magic World : ', " to have a better experience and access all the features, we ask you to complete your account on https://the-marauders.com : \n\n ") 
                        .addField(' step 1 :', "    click on \" GET STARTED \", and paste this ID : ` " + randomCode + " ` ") 
                        .addField(' step 2 :', "    ready ! you can buy items and modify your profile ") 
                        .setFooter(" We wish you a wonderful experience, The Marauders ", "https://cdn.discordapp.com/emojis/460106637026525184.png?v=1");
                
                    channel.send(embed);
                    channel.send("when you enter the server, your profile photo, your nickname and your discord ID are automatically stored in our database, for non-commercial purposes; if you do not"
                    +" want to be visible on the homepage http://the-marauders.rf.gd/, let us know by sending us a deactivation request owlketters@yandex.ru, or delete your account directly from the website");
                });
                console.log('compte créé ! --> '+name);
            } catch(error) {
                console.log('euh... ya eu une erreur');
                console.log(error);
            }
        } else {
            DB.profile(id).updateData('account/picture', avatar);
            
            let xp = profile.game.xp;
            level = profile.game.level;

            while(Math.pow(level,2.3)*10<xp) {
                level++;
            }

            DB.profile(id).updateData('game/level', level);
        }
    },DB.responseTime);
};

module.exports = check;