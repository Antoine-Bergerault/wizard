const Discord = require('discord.js');
let main = require('../bot.js');
let DB = main.database;
let firebase = require('firebase');

let quests = function(msg, id) {
    msg.channel.send('quests: ok');
}

module.exports = quests;